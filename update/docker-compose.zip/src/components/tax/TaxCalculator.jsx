import React, { useState, useEffect, useRef } from 'react';
import { Calculator, RefreshCw, Copy, Check, Keyboard, Wallet } from 'lucide-react';
import { Card } from '../ui/Card';

export default function TaxCalculator({
    title = "Simulasi Perhitungan PPh",
    onCalculate,
    className = "",
    initialDpp = '',
    initialRate = '',
    initialDiscount = '',
    onCopy,
    isReadOnly = false
}) {
    const [dpp, setDpp] = useState(initialDpp || '');
    const [rate, setRate] = useState(initialRate || '');
    const [discount, setDiscount] = useState(initialDiscount || '');
    const [pph, setPph] = useState(0);
    const [ppn, setPpn] = useState(0);
    const [dppNet, setDppNet] = useState(0);
    const [totalPayable, setTotalPayable] = useState(0);
    const [copied, setCopied] = useState(null); // 'pph', 'ppn', 'total', 'dppNet'
    const [isCalcMode, setIsCalcMode] = useState(false);

    // Track last values emitted to prevent feedback loops overwriting manual input
    const lastEmitted = useRef({ dpp: initialDpp, rate: initialRate });

    useEffect(() => {
        // Only sync from props if they actually changed for reasons other than our own calculation
        if (initialDpp !== undefined && initialDpp !== '' && String(initialDpp) !== String(lastEmitted.current.dpp)) {
            setDpp(initialDpp);
        }
        if (initialRate !== undefined && initialRate !== '' && String(initialRate) !== String(lastEmitted.current.rate)) {
            setRate(initialRate);
        }
        if (initialDiscount !== undefined && initialDiscount !== '' && String(initialDiscount) !== String(lastEmitted.current.discount)) {
            setDiscount(initialDiscount);
        }
    }, [initialDpp, initialRate, initialDiscount]);

    useEffect(() => {
        let dppValue = 0;

        if (isCalcMode) {
            // 1.000.000 -> 1000000
            const raw = dpp.toString().replace(/\./g, '');

            try {
                const sanitized = raw.replace(/[^0-9+\-*/().\s]/g, '');
                if (sanitized) {
                    // eslint-disable-next-line no-new-func
                    const result = new Function('return ' + sanitized)();
                    if (isFinite(result)) {
                        dppValue = result;
                    }
                }
            } catch (e) {
                // ignore
            }
        } else {
            dppValue = parseFloat(dpp) || 0;
        }

        const rateValue = parseFloat(rate) || 0;
        const discountValue = parseFloat(discount.toString().replace(/\./g, '')) || 0;
        const dppNet = (11 / 12) * (dppValue - discountValue);
        const calculatedPph = dppValue * (rateValue / 100);
        const calculatedPpn = dppNet * 0.12;
        const calculatedTotal = Math.ceil((dppValue - discountValue) + calculatedPpn - calculatedPph);

        setPph(calculatedPph);
        setPpn(calculatedPpn);
        setDppNet(dppNet);
        setTotalPayable(calculatedTotal);

        // Update guard ref before emitting
        lastEmitted.current = { dpp: dppValue, rate: rateValue, discount: discountValue, dppNet: dppNet };

        if (onCalculate) {
            onCalculate({ dpp: dppValue, rate: rateValue, pph: calculatedPph, ppn: calculatedPpn, totalPayable: calculatedTotal, discount: discountValue, dppNet: dppNet });
        }
    }, [dpp, rate, discount, isCalcMode, onCalculate]);

    const formatCurrency = (value) => {
        return new Intl.NumberFormat('id-ID', {
            style: 'currency',
            currency: 'IDR',
            minimumFractionDigits: 0,
            maximumFractionDigits: 0
        }).format(value);
    };

    const handleReset = () => {
        setDpp('');
        setRate('');
        setDiscount('');
        setPph(0);
    };

    const evaluateExpression = () => {
        try {
            const raw = dpp.toString().replace(/\./g, '');
            const sanitized = raw.replace(/[^0-9+\-*/().\s]/g, '');

            if (!sanitized) return;

            // eslint-disable-next-line no-new-func
            const result = new Function('return ' + sanitized)();

            if (isFinite(result)) {
                const formattedResult = Math.floor(result).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
                setDpp(formattedResult);

                const rateValue = parseFloat(rate) || 0;
                setPph(result * (rateValue / 100));
            }
        } catch (e) {
            console.error("Invalid expression");
        }
    };

    const handleKeyDown = (e) => {
        if (isCalcMode && e.key === 'Enter') {
            e.preventDefault();
            evaluateExpression();
        }
    };

    const formatDisplayValue = (val) => {
        if (!val) return '';
        if (!isNaN(val) && !val.toString().includes('+') && !val.toString().includes('-') && !val.toString().includes('*') && !val.toString().includes('/')) {
            return val.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
        }
        return val;
    };

    const handleDppChange = (e) => {
        let val = e.target.value;
        if (isCalcMode) {
            const raw = val.replace(/\./g, '');
            const formatted = raw.replace(/\d+/g, (match) => {
                return match.replace(/\B(?=(\d{3})+(?!\d))/g, ".");
            });
            setDpp(formatted);
        } else {
            const cleanVal = val.replace(/\./g, '').replace(/[^0-9]/g, '');
            setDpp(cleanVal);
        }
    };

    return (
        <Card className={className}>
            <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-6 border-b pb-2 dark:border-gray-700">
                {title}
            </h3>

            <div className="space-y-6">
                {/* DPP Input */}
                <div>
                    <div className="flex justify-between items-center mb-1">
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                            Dasar Pengenaan Pajak (DPP)
                        </label>
                        {!isReadOnly && <button
                            onClick={() => setIsCalcMode(!isCalcMode)}
                            className={`text-xs flex items-center gap-1 px-2 py-1 rounded-md transition-all ${isCalcMode ? 'bg-indigo-100 text-indigo-700 font-bold' : 'text-gray-500 hover:bg-gray-100'}`}
                            title={isCalcMode ? "Matikan Mode Rumus" : "Aktifkan Mode Rumus (Hitung Cepat)"}
                        >
                            {isCalcMode ? <Keyboard size={14} /> : <Calculator size={14} />}
                            {isCalcMode ? 'Mode Input' : 'Mode Rumus'}
                        </button>}
                    </div>
                    <div className="relative">
                        {!isCalcMode && <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 font-medium">Rp</span>}
                        <input
                            type="text"
                            value={isCalcMode ? dpp : formatDisplayValue(dpp)}
                            onChange={handleDppChange}
                            onKeyDown={handleKeyDown}
                            disabled={isReadOnly}
                            className={`w-full ${isCalcMode ? 'pl-4 font-mono text-indigo-600' : 'pl-10'} pr-4 py-3 rounded-xl border ${isCalcMode ? 'border-indigo-300 ring-2 ring-indigo-500/20' : 'border-gray-200'} dark:border-slate-700 bg-white dark:bg-slate-900 focus:ring-2 focus:ring-indigo-500 outline-none transition-all dark:text-white disabled:bg-gray-100 dark:disabled:bg-slate-800 disabled:cursor-not-allowed`}
                            placeholder={isCalcMode ? "Ketik rumus (cth: 1000000+500000) lalu ENTER" : "0"}
                        />
                        {isCalcMode && !isReadOnly && (
                            <button
                                onClick={evaluateExpression}
                                className="absolute right-2 top-1/2 -translate-y-1/2 text-xs bg-indigo-600 text-white px-3 py-1.5 rounded-lg font-bold hover:bg-indigo-700 transition-colors"
                            >
                                HITUNG
                            </button>
                        )}
                    </div>

                    {/* Operator Buttons (Calculator Mode Only) */}
                    {isCalcMode && !isReadOnly && (
                        <div className="grid grid-cols-4 gap-2 mt-2 animate-in slide-in-from-top-1">
                            {['+', '-', '*', '/'].map((op) => (
                                <button
                                    key={op}
                                    onClick={() => setDpp(prev => prev + op)}
                                    className="py-2 bg-gray-100 hover:bg-indigo-100 text-gray-700 hover:text-indigo-700 dark:bg-slate-800 dark:text-gray-300 dark:hover:bg-indigo-900/30 font-mono font-bold rounded-lg transition-colors border border-gray-200 dark:border-slate-700"
                                >
                                    {op === '*' ? 'x' : op === '/' ? '÷' : op}
                                </button>
                            ))}
                        </div>
                    )}
                </div>

                {/* Percentage Input */}
                <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Persentase Tarif (%)
                    </label>
                    <div className="relative">
                        <input
                            type="number"
                            value={rate}
                            onChange={(e) => setRate(e.target.value)}
                            disabled={isReadOnly}
                            className="w-full pl-4 pr-10 py-3 rounded-xl border border-gray-200 dark:border-slate-700 bg-white dark:bg-slate-900 focus:ring-2 focus:ring-indigo-500 outline-none transition-all dark:text-white disabled:bg-gray-100 dark:disabled:bg-slate-800 disabled:cursor-not-allowed"
                            placeholder="0"
                        />
                        <span className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 font-bold">%</span>
                    </div>
                </div>

                {/* Discount Input */}
                <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Potongan Harga
                    </label>
                    <div className="relative">
                        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 font-medium">Rp</span>
                        <input
                            type="text"
                            value={formatDisplayValue(discount)}
                            onChange={(e) => {
                                const val = e.target.value.replace(/\./g, '').replace(/[^0-9]/g, '');
                                setDiscount(val);
                            }}
                            disabled={isReadOnly}
                            className="w-full pl-10 pr-4 py-3 rounded-xl border border-gray-200 dark:border-slate-700 bg-white dark:bg-slate-900 focus:ring-2 focus:ring-indigo-500 outline-none transition-all dark:text-white disabled:bg-gray-100 dark:disabled:bg-slate-800 disabled:cursor-not-allowed"
                            placeholder="0"
                        />
                    </div>
                </div>

                {/* Result Display */}
                <div className="pt-4 border-t dark:border-gray-700 space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        {/* DPP Net Result */}
                        <div className="p-4 bg-slate-50 dark:bg-slate-900/20 rounded-xl border border-slate-100 dark:border-slate-800">
                            <div className="flex justify-between items-center mb-1">
                                <span className="text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">DPP Net</span>
                                <button
                                    onClick={() => {
                                        const val = Math.floor(dppNet);
                                        if (onCopy) onCopy(val, "DPP Net");
                                        else navigator.clipboard.writeText(val.toString());
                                        setCopied('dppNet');
                                        setTimeout(() => setCopied(null), 2000);
                                    }}
                                    className="text-slate-400 hover:text-slate-600 transition-colors"
                                >
                                    {copied === 'dppNet' ? <Check size={14} /> : <Copy size={14} />}
                                </button>
                            </div>
                            <p className="text-lg font-black text-slate-700 dark:text-slate-300">{formatCurrency(dppNet)}</p>
                        </div>

                        {/* PPh Result */}
                        <div className="p-4 bg-indigo-50 dark:bg-indigo-900/20 rounded-xl border border-indigo-100 dark:border-indigo-800">
                            <div className="flex justify-between items-center mb-1">
                                <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider">PPh Terutang</span>
                                <button
                                    onClick={() => {
                                        const val = Math.floor(pph);
                                        if (onCopy) onCopy(val, "PPh Terutang");
                                        else navigator.clipboard.writeText(val.toString());
                                        setCopied('pph');
                                        setTimeout(() => setCopied(null), 2000);
                                    }}
                                    className="text-indigo-400 hover:text-indigo-600 transition-colors"
                                >
                                    {copied === 'pph' ? <Check size={14} /> : <Copy size={14} />}
                                </button>
                            </div>
                            <p className="text-lg font-black text-indigo-700 dark:text-indigo-300">{formatCurrency(pph)}</p>
                        </div>

                        {/* PPN Result */}
                        <div className="p-4 bg-emerald-50 dark:bg-emerald-900/20 rounded-xl border border-emerald-100 dark:border-emerald-800">
                            <div className="flex justify-between items-center mb-1">
                                <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider">PPN (12%)</span>
                                <button
                                    onClick={() => {
                                        const val = Math.floor(ppn);
                                        if (onCopy) onCopy(val, "PPN (12%)");
                                        else navigator.clipboard.writeText(val.toString());
                                        setCopied('ppn');
                                        setTimeout(() => setCopied(null), 2000);
                                    }}
                                    className="text-emerald-400 hover:text-emerald-600 transition-colors"
                                >
                                    {copied === 'ppn' ? <Check size={14} /> : <Copy size={14} />}
                                </button>
                            </div>
                            <p className="text-lg font-black text-emerald-700 dark:text-emerald-300">{formatCurrency(ppn)}</p>
                        </div>
                    </div>

                    {/* Total Payable Result */}
                    <div className="p-5 bg-gradient-to-r from-indigo-600 to-indigo-500 rounded-2xl shadow-lg shadow-indigo-500/20 text-white">
                        <div className="flex justify-between items-center mb-2">
                            <div className="flex items-center gap-2">
                                <Wallet size={18} className="text-indigo-200" />
                                <span className="text-xs font-black uppercase tracking-[0.2em] text-indigo-100">Total yang harus dibayar</span>
                            </div>
                            <button
                                onClick={() => {
                                    const val = Math.ceil(totalPayable);
                                    if (onCopy) onCopy(val, "Total Bayar");
                                    else navigator.clipboard.writeText(val.toString());
                                    setCopied('total');
                                    setTimeout(() => setCopied(null), 2000);
                                }}
                                className="p-2 bg-white/20 hover:bg-white/30 rounded-lg transition-all"
                                title="Salin Angka Murni"
                            >
                                {copied === 'total' ? <Check size={16} /> : <Copy size={16} />}
                            </button>
                        </div>
                        <div className="flex items-baseline gap-2">
                            <p className="text-3xl font-black tracking-tight">{formatCurrency(totalPayable)}</p>
                            {copied === 'total' && <span className="text-[10px] font-bold bg-white/20 px-2 py-0.5 rounded-full animate-in fade-in slide-in-from-left-2">Angka Tersalin!</span>}
                        </div>
                        <p className="text-[10px] text-indigo-100/60 mt-2 font-medium italic">Rumus: (DPP - Potongan) + PPN 12% - PPh Terutang (Rounding Up)</p>
                    </div>
                </div>

                {/* Actions */}
                {!isReadOnly && <div className="flex justify-end pt-2">
                    <button
                        onClick={handleReset}
                        className="px-4 py-2 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 flex items-center gap-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors"
                    >
                        <RefreshCw size={16} /> Reset
                    </button>
                </div>}
            </div>
        </Card>
    );
}
